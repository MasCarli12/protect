### install semua security *V1*
```
bash <(curl -s https://raw.githubusercontent.com/liaacans/installers/refs/heads/main/installprotectall.sh)
```

### INSTALL SEMUA SECURITY *V2*
```
bash <(curl -s https://raw.githubusercontent.com/liaacans/installers/refs/heads/main/installprotectallv2.sh)
```

### FIXED ANTI DDOS
```
bash <(curl -s https://raw.githubusercontent.com/liaacans/installers/refs/heads/main/fixddos.sh)
```

### INSTALL ANTI DDOS
```
bash <(curl -s https://raw.githubusercontent.com/liaacans/installers/refs/heads/main/antiddos.sh)
```

### INSTALL SECURITY
```
bash <(curl -s https://raw.githubusercontent.com/liaacans/installers/refs/heads/main/security.sh)
```

### INSTALL SECURITY V2
```
bash <(curl -s https://raw.githubusercontent.com/liaacans/installers/refs/heads/main/security-bot.sh)
```

### INSTALL SECURITY V3
```
bash <(curl -s https://raw.githubusercontent.com/liaacans/installers/refs/heads/main/security-v3.sh)
```
